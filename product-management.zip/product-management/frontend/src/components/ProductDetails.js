import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import API from '../api';

const ProductDetails = () => {
  const { id } = useParams();
  const [product, setProduct] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchProduct = async () => {
      const response = await API.get(`/products/${id}`);
      setProduct(response.data);
    };

    fetchProduct();
  }, [id]);

  const handleDelete = async () => {
    await API.delete(`/products/${id}`);
    navigate('/products');
  };

  if (!product) return <p>Loading...</p>;

  return (
    <div>
      <h2>{product.name}</h2>
      <p>Price: ${product.price}</p>
      <p>Category: {product.category}</p>
      <p>In Stock: {product.inStock ? 'Yes' : 'No'}</p>
      {product.image && <img src={`http://localhost:5000/${product.image}`} alt={product.name} />}
      <br />
      <button onClick={() => navigate(`/edit-product/${id}`)}>Edit</button>
      <button onClick={handleDelete} style={{ color: 'red' }}>
        Delete
      </button>
    </div>
  );
};

export default ProductDetails;
