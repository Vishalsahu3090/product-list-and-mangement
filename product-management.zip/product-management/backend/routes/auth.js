const express = require('express');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const User = require('../models/User');

const router = express.Router();

// Example Authentication Route in Backend
router.post('/login', (req, res) => {
    const { username, password } = req.body;
  
    // Hardcoded admin credentials
    const adminUsername = 'admin';
    const adminPassword = 'adminpassword';
  
    // Validate credentials
    if (username === adminUsername && password === adminPassword) {
      const token = jwt.sign({ username }, 'your_jwt_secret', { expiresIn: '1h' });
      return res.json({ token });
    }
  
    return res.status(401).json({ message: 'Invalid credentials' });
  });
  

module.exports = router;
